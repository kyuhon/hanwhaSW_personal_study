import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Users, 
  FileText, 
  Calculator, 
  Bell, 
  Search, 
  Menu, 
  X, 
  ChevronDown, 
  ChevronRight, 
  Settings, 
  LogOut, 
  User, 
  TrendingUp, 
  Calendar, 
  MessageCircle, 
  AlertTriangle,
  Sparkles,
  TrendingDown,
  Target,
  AlertCircle,
  BarChart3,
  Megaphone,
  Briefcase,
  CreditCard,
  Wrench,
  Truck,
  FileCheck,
  CheckCircle,
  ArrowUpRight,
  ArrowDownRight,
  Shield,
  List
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AssetsPage } from './components/pages/AssetsPage';
import { ProfitabilityPage } from './components/pages/ProfitabilityPage';
import { CustomersPage } from './components/pages/CustomersPage';
import { SegmentsPage } from './components/pages/SegmentsPage';
import { BlacklistPage } from './components/pages/BlacklistPage';
import { ContractsPage } from './components/pages/ContractsPage';
import { PaymentsPage } from './components/pages/PaymentsPage';
import { OverduePage } from './components/pages/OverduePage';
import { MaintenancePage } from './components/pages/MaintenancePage';
import { ReturnsPage } from './components/pages/ReturnsPage';
import { RenewalsPage } from './components/pages/RenewalsPage';
import { CampaignsPage } from './components/pages/CampaignsPage';
import { UpsellPage } from './components/pages/UpsellPage';
import { RevenueAnalysisPage } from './components/pages/RevenueAnalysisPage';
import { InventoryForecastPage } from './components/pages/InventoryForecastPage';
import { SettingsPage } from './components/pages/SettingsPage';
import { CustomerAnalyticsPage } from './components/pages/CustomerAnalyticsPage';
import { AnalyticsReportPage } from './components/pages/AnalyticsReportPage';
import { CustomerBehaviorPage } from './components/pages/CustomerBehaviorPage';
import { LTVAnalysisPage } from './components/pages/LTVAnalysisPage';
import { ChurnPredictionPage } from './components/pages/ChurnPredictionPage';
import { ConsultationPage } from './components/pages/ConsultationPage';
import { CustomerResponsePage } from './components/pages/CustomerResponsePage';
import { FeedbackPage } from './components/pages/FeedbackPage';
import { CouponPage } from './components/pages/CouponPage';
import { ApprovalPage } from './components/pages/ApprovalPage';
import { SurveyAnalysisPage } from './components/pages/SurveyAnalysisPage';
import { MenuManagementPage } from './components/pages/MenuManagementPage';
import { ProfilePage } from './components/pages/ProfilePage';
import { AIInsightsModal } from './components/AIInsightsModal';

export default function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [openSections, setOpenSections] = useState<string[]>([]);
  const [openSubSections, setOpenSubSections] = useState<string[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showAllNotifications, setShowAllNotifications] = useState(false);
  const [customerResponseTab, setCustomerResponseTab] = useState<'inquiry' | 'feedback' | 'complaint' | 'survey'>('inquiry');

  const toggleSection = (section: string) => {
    setOpenSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const toggleSubSection = (subSection: string) => {
    setOpenSubSections(prev =>
      prev.includes(subSection)
        ? prev.filter(s => s !== subSection)
        : [...prev, subSection]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-screen w-64 xl:w-72 bg-white border-gray-200 border-r p-6 overflow-y-auto">
        {/* Logo */}
        <div className="mb-6">
          <h2 className="mb-1" style={{ fontFamily: 'Arial', fontWeight: 'bold', fontSize: '25px', color: '#3366CC' }}>Rental Brain</h2>
          <p className="text-sm text-gray-500">CRM · ERP Platform</p>
        </div>

        {/* User Info & Notifications */}
        <div className="mb-6 pb-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="relative flex-1">
              <div 
                className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 rounded-lg p-2 -m-2 transition-colors"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-900">DevOops</p>
                  <p className="text-xs text-gray-500">시스템 관리자</p>
                </div>
              </div>

              {/* Profile Menu Dropdown */}
              {showProfileMenu && (
                <div className="absolute left-0 top-full mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                  <div className="p-2">
                    <button
                      onClick={() => {
                        setCurrentPage('profile');
                        setShowProfileMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <User className="w-4 h-4" />
                      <span>내 정보</span>
                    </button>
                    <button
                      onClick={() => {
                        setCurrentPage('settings');
                        setShowProfileMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Settings className="w-4 h-4" />
                      <span>설정</span>
                    </button>
                    <div className="border-t border-gray-200 my-2"></div>
                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        alert('로그아웃 되었습니다.');
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>로그아웃</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div className="relative">
              <button 
                className="relative p-2 rounded-lg transition-colors hover:bg-gray-100"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
            </div>
          </div>
        </div>

        <nav className="space-y-1">
          {/* 대시보드 */}
          <NavItem
            icon={<LayoutDashboard className="w-5 h-5" />}
            label="대시보드"
            active={currentPage === 'dashboard'}
            onClick={() => setCurrentPage('dashboard')}
          />

          {/* 고객관리 */}
          <AccordionSection
            icon={<Users className="w-5 h-5" />}
            label="고객관리"
            isOpen={openSections.includes('customer')}
            onToggle={() => toggleSection('customer')}
            color="#88AA82"
          >
            <SubNavItem
              icon={<Users className="w-4 h-4" />}
              label="고객목록"
              active={currentPage === 'customers'}
              onClick={() => setCurrentPage('customers')}
            />
            <SubNavItem
              icon={<MessageCircle className="w-4 h-4" />}
              label="고객응대"
              active={currentPage === 'customer-response'}
              onClick={() => setCurrentPage('customer-response')}
            />
            <SubNavItem
              icon={<TrendingUp className="w-4 h-4" />}
              label="고객분석"
              active={currentPage === 'customer-analytics'}
              onClick={() => setCurrentPage('customer-analytics')}
            />
            <SubNavItem
              icon={<AlertTriangle className="w-4 h-4" />}
              label="연체 관리"
              active={currentPage === 'overdue'}
              onClick={() => setCurrentPage('overdue')}
              badge={11}
            />
          </AccordionSection>

          {/* 영업관리 */}
          <AccordionSection
            icon={<Briefcase className="w-5 h-5" />}
            label="영업관리"
            isOpen={openSections.includes('sales')}
            onToggle={() => toggleSection('sales')}
            color="#6B8EAE"
          >
            <SubNavItem
              icon={<FileText className="w-4 h-4" />}
              label="견적(상담)"
              active={currentPage === 'consultation'}
              onClick={() => setCurrentPage('consultation')}
            />
            <SubNavItem
              icon={<CreditCard className="w-4 h-4" />}
              label="계약(결재)"
              active={currentPage === 'contracts'}
              onClick={() => setCurrentPage('contracts')}
            />
            <SubNavItem
              icon={<Megaphone className="w-4 h-4" />}
              label="캠페인"
              active={currentPage === 'campaigns'}
              onClick={() => setCurrentPage('campaigns')}
            />
          </AccordionSection>

          {/* 제품관리 */}
          <AccordionSection
            icon={<Package className="w-5 h-5" />}
            label="제품관리"
            isOpen={openSections.includes('assets')}
            onToggle={() => toggleSection('assets')}
            color="#FFC857"
          >
            <SubNavItem
              icon={<Package className="w-4 h-4" />}
              label="제품관리"
              active={currentPage === 'assets'}
              onClick={() => setCurrentPage('assets')}
            />
            <SubNavItem
              icon={<Wrench className="w-4 h-4" />}
              label="AS/정기점검"
              active={currentPage === 'maintenance'}
              onClick={() => setCurrentPage('maintenance')}
              badge={24}
            />
          </AccordionSection>

          {/* 결재관리 */}
          <NavItem
            icon={<FileCheck className="w-5 h-5" />}
            label="결재관리"
            active={currentPage === 'approval'}
            onClick={() => setCurrentPage('approval')}
          />

          {/* 관리자 메뉴 */}
          <NavItem
            icon={<Settings className="w-5 h-5" />}
            label="관리자 메뉴"
            active={currentPage === 'settings'}
            onClick={() => setCurrentPage('settings')}
          />
        </nav>

      </div>

      {/* Main Content */}
      <div className="ml-64 xl:ml-72 p-6 xl:p-8">
        {currentPage === 'dashboard' && <DashboardPage />}
        {currentPage === 'assets' && <AssetsPage />}
        {currentPage === 'profitability' && <ProfitabilityPage />}
        {currentPage === 'customers' && <CustomersPage />}
        {currentPage === 'segments' && <SegmentsPage />}
        {currentPage === 'blacklist' && <BlacklistPage />}
        {currentPage === 'contracts' && <ContractsPage />}
        {currentPage === 'payments' && <PaymentsPage />}
        {currentPage === 'overdue' && <OverduePage />}
        {currentPage === 'maintenance' && <MaintenancePage />}
        {currentPage === 'returns' && <ReturnsPage />}
        {currentPage === 'renewals' && <RenewalsPage />}
        {currentPage === 'campaigns' && <CampaignsPage />}
        {currentPage === 'upsell' && <UpsellPage />}
        {currentPage === 'revenue-analysis' && <RevenueAnalysisPage />}
        {currentPage === 'inventory-forecast' && <InventoryForecastPage />}
        {currentPage === 'settings' && <SettingsPage />}
        {currentPage === 'customer-analytics' && <CustomerAnalyticsPage />}
        {currentPage === 'analytics-report' && <AnalyticsReportPage />}
        {currentPage === 'customer-behavior' && <CustomerBehaviorPage />}
        {currentPage === 'ltv-analysis' && <LTVAnalysisPage />}
        {currentPage === 'churn-prediction' && <ChurnPredictionPage />}
        {currentPage === 'consultation' && <ConsultationPage />}
        {currentPage === 'customer-response' && <CustomerResponsePage onNavigate={(page) => { if (page === 'survey-analysis') setCustomerResponseTab('survey'); setCurrentPage(page); }} initialTab={customerResponseTab} />}
        {currentPage === 'survey-analysis' && <SurveyAnalysisPage onBack={() => { setCustomerResponseTab('survey'); setCurrentPage('customer-response'); }} />}
        {currentPage === 'feedback' && <FeedbackPage />}
        {currentPage === 'coupon' && <CouponPage />}
        {currentPage === 'approval' && <ApprovalPage />}
        {currentPage === 'menu-management' && <MenuManagementPage />}
        {currentPage === 'profile' && <ProfilePage onBack={() => setCurrentPage('dashboard')} />}
      </div>

      {/* Notification Modal - Outside Sidebar */}
      {showNotifications && (
        <div className="fixed left-72 xl:left-80 top-24 w-80 xl:w-96 bg-white border border-gray-300 rounded-xl shadow-2xl z-[9999]">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-xl">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              <h3 className="text-sm text-gray-900">알림</h3>
              <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">5</span>
            </div>
            <button 
              onClick={() => setShowNotifications(false)}
              className="p-1 hover:bg-white/50 rounded transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            <NotificationItem
              icon={<FileCheck className="w-5 h-5 text-green-500" />}
              title="전자결재 승인"
              description="김철수 대리의 장비 구매 요청이 승인되었습니다"
              time="5분 전"
              type="approval"
            />
            <NotificationItem
              icon={<Wrench className="w-5 h-5 text-orange-500" />}
              title="정기 점검 임박"
              description="미래산업 - 회의실 장비 점검이 7일 후 예정입니다"
              time="1시간 전"
              type="maintenance"
            />
            <NotificationItem
              icon={<Calendar className="w-5 h-5 text-blue-500" />}
              title="계약 만료 예정"
              description="스타트업코리아 - 오피스 가구 계약이 14일 후 만료됩니다"
              time="2시간 전"
              type="contract"
            />
            <NotificationItem
              icon={<AlertTriangle className="w-5 h-5 text-red-500" />}
              title="전자결재 반려"
              description="박영희 과장의 추가 제품 요청이 반려되었습니다"
              time="3시간 전"
              type="rejection"
            />
            <NotificationItem
              icon={<Wrench className="w-5 h-5 text-orange-500" />}
              title="AS 점검 임박"
              description="비즈카페 - 업무용 PC AS가 5일 후 예정입니다"
              time="5시간 전"
              type="maintenance"
            />
          </div>
          <div className="p-3 border-t border-gray-200 bg-gray-50 rounded-b-xl">
            <button 
              className="w-full text-center text-sm text-blue-600 hover:text-blue-700 transition-colors"
              onClick={() => {
                setShowNotifications(false);
                setShowAllNotifications(true);
              }}
            >
              모든 알림 보기
            </button>
          </div>
        </div>
      )}

      {/* All Notifications Modal */}
      {showAllNotifications && (
        <>
          <div className="fixed inset-0 bg-black/50 z-[9998]" onClick={() => setShowAllNotifications(false)}></div>
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-4xl bg-white rounded-xl shadow-2xl z-[9999] max-h-[85vh] flex flex-col">
            {/* Header */}
            <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl text-gray-900">전체 알림</h2>
                <span className="text-xs bg-red-500 text-white px-2 py-1 rounded-full">25</span>
              </div>
              <button 
                onClick={() => setShowAllNotifications(false)}
                className="p-2 hover:bg-white/50 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Tabs */}
            <div className="border-b border-gray-200 px-6">
              <div className="flex gap-4">
                <button className="px-4 py-3 text-sm border-b-2 border-blue-600 text-blue-600">
                  전체 (25)
                </button>
                <button className="px-4 py-3 text-sm text-gray-600 hover:text-gray-900">
                  결재 (8)
                </button>
                <button className="px-4 py-3 text-sm text-gray-600 hover:text-gray-900">
                  정기 점검 (12)
                </button>
                <button className="px-4 py-3 text-sm text-gray-600 hover:text-gray-900">
                  계약 (5)
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-3">
                {/* Today */}
                <div className="mb-4">
                  <h3 className="text-sm text-gray-500 mb-3">오늘</h3>
                  <div className="space-y-2">
                    <AllNotificationItem
                      icon={<FileCheck className="w-5 h-5 text-green-500" />}
                      title="전자결재 승인"
                      description="김철수 대리의 장비 구매 요청이 승인되었습니다"
                      time="5분 전"
                      type="approval"
                      isNew={true}
                    />
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="정기 점검 임박"
                      description="미래산업 - 회의실 장비 점검이 7일 후 예정입니다"
                      time="1시간 전"
                      type="maintenance"
                      isNew={true}
                    />
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 만료 예정"
                      description="스타트업코리아 - 오피스 가구 계약이 14일 후 만료됩니다"
                      time="2시간 전"
                      type="contract"
                      isNew={true}
                    />
                    <AllNotificationItem
                      icon={<AlertTriangle className="w-5 h-5 text-red-500" />}
                      title="전자결재 반려"
                      description="박영희 과장의 추가 제품 요청이 반려되었습니다"
                      time="3시간 전"
                      type="rejection"
                      isNew={true}
                    />
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="AS 점검 임박"
                      description="비즈카페 - 업무용 PC AS가 5일 후 예정입니다"
                      time="5시간 전"
                      type="maintenance"
                      isNew={true}
                    />
                  </div>
                </div>

                {/* Yesterday */}
                <div className="mb-4">
                  <h3 className="text-sm text-gray-500 mb-3">어제</h3>
                  <div className="space-y-2">
                    <AllNotificationItem
                      icon={<FileCheck className="w-5 h-5 text-green-500" />}
                      title="전자결재 승인"
                      description="이지훈 과장의 사무기기 교체 요청이 승인되었습니다"
                      time="19시간 전"
                      type="approval"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 갱신 완료"
                      description="테크솔루션 - 업무용 PC 계약이 갱신되었습니다"
                      time="20시간 전"
                      type="contract"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="정기 점검 완료"
                      description="디지털플러스 - 회의실 장비 점검이 완료되었습니다"
                      time="22시간 전"
                      type="maintenance"
                      isNew={false}
                    />
                  </div>
                </div>

                {/* This Week */}
                <div className="mb-4">
                  <h3 className="text-sm text-gray-500 mb-3">이번 주</h3>
                  <div className="space-y-2">
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 만료 예정"
                      description="그린오피스 - 오피스 가구 계약이 30일 후 만료됩니다"
                      time="2일 전"
                      type="contract"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<AlertTriangle className="w-5 h-5 text-red-500" />}
                      title="전자결재 반려"
                      description="최민수 대리의 추가 장비 요청이 반려되었습니다"
                      time="3일 전"
                      type="rejection"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<FileCheck className="w-5 h-5 text-green-500" />}
                      title="전자결재 승인"
                      description="정수연 차장의 장비 업그레이드 요청이 승인되었습니다"
                      time="3일 전"
                      type="approval"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="정기 점검 임박"
                      description="스마트워크 - 사무기기 점검이 10일 후 예정입니다"
                      time="4일 전"
                      type="maintenance"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 체결 완료"
                      description="이노베이션랩 - 새로운 오피스 가구 계약이 체결되었습니다"
                      time="5일 전"
                      type="contract"
                      isNew={false}
                    />
                  </div>
                </div>

                {/* Earlier */}
                <div>
                  <h3 className="text-sm text-gray-500 mb-3">이전 알림</h3>
                  <div className="space-y-2">
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="AS 점검 완료"
                      description="퓨처테크 - 업무용 PC AS가 완료되었습니다"
                      time="1주일 전"
                      type="maintenance"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<FileCheck className="w-5 h-5 text-green-500" />}
                      title="전자결재 승인"
                      description="강민호 부장의 장비 추가 요청이 승인되었습니다"
                      time="1주일 전"
                      type="approval"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 갱신 완료"
                      description="비즈니스허브 - 회의실 장비 계약이 갱신되었습니다"
                      time="2주일 전"
                      type="contract"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<AlertTriangle className="w-5 h-5 text-red-500" />}
                      title="전자결재 반려"
                      description="홍지민 과장의 추가 제품 요청이 반려되었습니다"
                      time="2주일 전"
                      type="rejection"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Wrench className="w-5 h-5 text-orange-500" />}
                      title="정기 점검 임박"
                      description="글로벌IT - 사무기기 점검이 예정되어 있습니다"
                      time="2주일 전"
                      type="maintenance"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<FileCheck className="w-5 h-5 text-green-500" />}
                      title="전자결재 승인"
                      description="박서연 대리의 장비 교체 요청이 승인되었습니다"
                      time="3주일 전"
                      type="approval"
                      isNew={false}
                    />
                    <AllNotificationItem
                      icon={<Calendar className="w-5 h-5 text-blue-500" />}
                      title="계약 만료 예정"
                      description="엔터프라이즈코리아 - 업무용 PC 계약 만료 안내"
                      time="3주일 전"
                      type="contract"
                      isNew={false}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-gray-200 bg-gray-50 rounded-b-xl flex justify-between items-center">
              <button className="text-sm text-gray-600 hover:text-gray-900">
                모두 읽음으로 표시
              </button>
              <button 
                onClick={() => setShowAllNotifications(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                닫기
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// NavItem Component
function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <div
      className={`px-4 py-3 rounded-lg cursor-pointer transition-colors ${
        active ? 'bg-blue-50 text-blue-600 border border-blue-200' : 'text-gray-600 hover:bg-gray-50'
      }`}
      onClick={onClick}
    >
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-sm">{label}</span>
      </div>
    </div>
  );
}

// Dashboard Page Component
function DashboardPage() {
  const [showAIModal, setShowAIModal] = useState(false);

  // Segment Data for Bar Chart
  const segmentData = [
    { segment: 'VIP', customers: 48, revenue: 780 },
    { segment: '안정 고객', customers: 142, revenue: 520 },
    { segment: '신규 고객', customers: 58, revenue: 180 },
    { segment: '미납 고객', customers: 11, revenue: 95 },
    { segment: 'AS 빈번 고객', customers: 19, revenue: 340 },
    { segment: '이탈위험 고객', customers: 32, revenue: 220 },
    { segment: '해지 요청 고객', customers: 11, revenue: 140 },
    { segment: '잠재 고가 고객', customers: 24, revenue: 580 },
    { segment: '블랙리스트', customers: 5, revenue: 80 },
  ];

  // Quarterly Customer Growth Data
  const quarterlyData = [
    { quarter: '1분기', newCustomers: 52, existingCustomers: 45 },
    { quarter: '2분기', newCustomers: 68, existingCustomers: 62 },
    { quarter: '3분기', newCustomers: 74, existingCustomers: 85 },
    { quarter: '4분기', newCustomers: 87, existingCustomers: 78 },
  ];

  // Asset Status Data
  const assetStatusData = [
    { name: '렌탈 중', value: 342, color: '#60A5FA' },
    { name: '대여 가능', value: 158, color: '#34D399' },
    { name: '수리/점검', value: 28, color: '#FBBF24' },
  ];

  return (
    <div className="w-full max-w-full xl:max-w-[1440px] mx-auto my-[-6px] px-6">
      {/* HEADER */}
      <div className="mb-4 md:mb-6">
        <h1 className="text-2xl mb-1">Rental Brain</h1>
        <p className="text-sm text-gray-500">기업 고객 중심 렌탈 비즈니스 인텔리전스</p>
      </div>

      {/* TOP 4 CIRCULAR GAUGE CARDS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-3 md:gap-4 mb-4 md:mb-6">
        <CircularGaugeCard
          title="월 매출 분석"
          subtitle="월간 달성액"
          value="₩17.0억"
          subValue="목표 ₩18.5억"
          percentage={92}
          color="#A78BFA"
          gradientId="purple-gradient"
        />
        <CircularGaugeCard
          title="상담 처리 현황"
          subtitle="처리 완료"
          value="1"
          subValue="전체 4건"
          percentage={25}
          color="#34D399"
          gradientId="green-gradient"
        />
        <CircularGaugeCard
          title="고객사 관할 이용률"
          subtitle="현재 이용 중"
          value="87"
          subValue="총 103개사"
          percentage={84.5}
          color="#FB7185"
          gradientId="pink-gradient"
        />
        <CircularGaugeCard
          title="자동 캠페인 현황"
          subtitle="활성 캠페인"
          value="22"
          subValue="총 30개"
          percentage={73.3}
          color="#60A5FA"
          gradientId="blue-gradient"
        />
      </div>

      {/* CUSTOMER SEGMENT BAR CHART + PRIORITY ALERTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4 md:mb-6">
        {/* Customer Segment Bar Chart - 2 columns */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-4 md:p-6">
          <h3 className="text-base mb-3 md:mb-4 text-gray-700">고객 세그먼트</h3>
          <ResponsiveContainer width="100%" height={250} className="md:h-[300px]">
          <BarChart data={segmentData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis 
              dataKey="segment" 
              tick={{ fontSize: 11, fill: '#9ca3af' }}
              axisLine={{ stroke: '#e5e7eb' }}
            />
            <YAxis 
              yAxisId="left"
              orientation="left"
              tick={{ fontSize: 11, fill: '#9ca3af' }}
              label={{ 
                value: '고객 수', 
                angle: -90, 
                position: 'insideLeft', 
                style: { fontSize: 11, fill: '#6b7280' } 
              }}
              axisLine={{ stroke: '#e5e7eb' }}
            />
            <YAxis 
              yAxisId="right"
              orientation="right"
              tick={{ fontSize: 11, fill: '#9ca3af' }}
              label={{ 
                value: '월 평균 매출 (만원)', 
                angle: 90, 
                position: 'insideRight', 
                style: { fontSize: 11, fill: '#6b7280' } 
              }}
              axisLine={{ stroke: '#e5e7eb' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                fontSize: '12px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
              }}
              formatter={(value: any, name: string) => {
                if (name === 'customers') return [value + '개사', '고객 수'];
                if (name === 'revenue') return [value + '만원', '월 평균 매출'];
                return [value, name];
              }}
            />
            <Legend 
              wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
              formatter={(value: string) => {
                const labels: { [key: string]: string } = {
                  'customers': '고객 수',
                  'revenue': '월 평균 매출'
                };
                return labels[value] || value;
              }}
            />
            <Bar 
              yAxisId="left" 
              dataKey="customers" 
              fill="#60A5FA" 
              name="customers"
              radius={[4, 4, 0, 0]}
              maxBarSize={40}
            />
            <Bar 
              yAxisId="right" 
              dataKey="revenue" 
              fill="#C4B5FD" 
              name="revenue"
              radius={[4, 4, 0, 0]}
              maxBarSize={40}
            />
          </BarChart>
        </ResponsiveContainer>
        </div>

        {/* Priority Alerts Card - 1 column */}
        <div className="bg-white rounded-xl shadow-md p-4 md:p-6">
          <div className="flex items-center gap-2 mb-3 md:mb-4">
            <Bell className="w-5 h-5 text-green-500" />
            <h3 className="text-base text-gray-700">우선순위 알림</h3>
          </div>
          <div className="space-y-3">
            <PriorityAlertItem
              icon={<AlertTriangle className="w-5 h-5 text-red-500" />}
              title="결제 연체 중"
              description="11개 기업 결제 연체"
              count={11}
              bgColor="bg-red-50"
            />
            <PriorityAlertItem
              icon={<Calendar className="w-5 h-5 text-orange-500" />}
              title="계약 갱신 임박"
              description="5건 만료 임박"
              count={5}
              bgColor="bg-orange-50"
            />
            <PriorityAlertItem
              icon={<MessageCircle className="w-5 h-5 text-blue-500" />}
              title="고객 문의 대기"
              description="8건 문의 대기 중"
              count={8}
              bgColor="bg-blue-50"
            />
          </div>
        </div>
      </div>

      {/* AI Insights Modal */}
      {showAIModal && <AIInsightsModal onClose={() => setShowAIModal(false)} />}

      {/* BOTTOM 3 SECTIONS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Quarterly Customer Growth */}
        <div className="bg-white rounded-xl shadow-md p-4 md:p-6">
          <div className="flex items-center justify-between mb-3 md:mb-4 gap-2">
            <h3 className="text-sm md:text-base text-gray-700">분기별 고객 수</h3>
            <select className="text-xs md:text-sm border border-gray-300 rounded-lg px-2 md:px-3 py-1 md:py-1.5 flex-shrink-0">
              <option>2024년</option>
              <option>2023년</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={quarterlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="quarter" tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: '12px'
                }}
              />
              <Legend 
                wrapperStyle={{ fontSize: '11px' }}
                formatter={(value: string) => {
                  const labels: { [key: string]: string } = {
                    'newCustomers': '신규 고객',
                    'existingCustomers': '전환 고객'
                  };
                  return labels[value] || value;
                }}
              />
              <Line 
                type="monotone" 
                dataKey="newCustomers" 
                stroke="#6366F1" 
                strokeWidth={3}
                dot={{ fill: '#6366F1', r: 5 }}
                name="newCustomers"
              />
              <Line 
                type="monotone" 
                dataKey="existingCustomers" 
                stroke="#8B5CF6" 
                strokeWidth={3}
                dot={{ fill: '#8B5CF6', r: 5 }}
                name="existingCustomers"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* AI Insights Card */}
        <div 
          className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl shadow-md p-4 md:p-6 border border-purple-200 cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => setShowAIModal(true)}
        >
          <div className="flex items-center gap-2 mb-3 md:mb-4 flex-wrap">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <h3 className="text-sm font-medium text-gray-900">AI 인사이트</h3>
            <span className="text-xs bg-purple-600 text-white px-2 py-0.5 rounded-full">실시간</span>
          </div>
          
          {/* 요약 카드들 */}
          <div className="space-y-2 md:space-y-3">
            <div className="bg-white rounded-lg p-2 md:p-3 border border-green-200">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-green-600" />
                <span className="text-xs font-medium text-gray-900">매출 트렌드</span>
              </div>
              <p className="text-xs text-gray-600">VIP 고객군 +23% 증가</p>
            </div>

            <div className="bg-white rounded-lg p-2 md:p-3 border border-red-200">
              <div className="flex items-center gap-2 mb-1">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-xs font-medium text-gray-900">이탈 위험</span>
              </div>
              <p className="text-xs text-gray-600">32개사 이탈 징후 감지</p>
            </div>

            <div className="bg-white rounded-lg p-2 md:p-3 border border-blue-200">
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-medium text-gray-900">크로스셀 기회</span>
              </div>
              <p className="text-xs text-gray-600">24개사 잠재 고객 발견</p>
            </div>
          </div>

          {/* 클릭 안내 */}
          <div className="mt-3 md:mt-4 pt-2 md:pt-3 border-t border-purple-200">
            <p className="text-xs text-center text-purple-600 flex items-center justify-center gap-1">
              <span>클릭하여 상세보기</span>
              <ChevronRight className="w-3 h-3" />
            </p>
          </div>
        </div>

        {/* Asset Status Donut Chart */}
        <div className="bg-white rounded-xl shadow-md p-4 md:p-6">
          <h3 className="text-sm md:text-base mb-3 md:mb-4 text-gray-700">제품 현황</h3>
          <ResponsiveContainer width="100%" height={180}>
            <RechartsPieChart>
              <Pie
                data={assetStatusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {assetStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: '12px'
                }}
              />
            </RechartsPieChart>
          </ResponsiveContainer>
          <div className="space-y-2">
            {assetStatusData.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-gray-700">{item.name}</span>
                </div>
                <span className="font-medium text-gray-900">{item.value}개</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Core KPI Card Component
function CoreKPICard({ 
  icon, 
  value, 
  label, 
  change, 
  isPositive,
  progressValue,
  progressColor
}: { 
  icon: React.ReactNode, 
  value: string, 
  label: string, 
  change: string, 
  isPositive: boolean,
  progressValue: number,
  progressColor: string
}) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-3">
        {icon}
        {change && (
          <div className={`flex items-center gap-1 text-xs ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
            <span>{change}</span>
          </div>
        )}
      </div>
      <div className="text-2xl mb-1">{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
      <div className="mt-2">
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div
            className={`h-2.5 rounded-full ${progressColor}`}
            style={{ width: `${progressValue}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
}

// Segment Card Component
function SegmentCard({ 
  label, 
  count, 
  avgRevenue, 
  color, 
  borderColor, 
  textColor, 
  icon,
  percentage
}: { 
  label: string, 
  count: string, 
  avgRevenue: string, 
  color: string, 
  borderColor: string, 
  textColor: string, 
  icon: React.ReactNode,
  percentage: number
}) {
  return (
    <div className={`${color} ${borderColor} rounded-xl p-4 shadow-sm`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm">{label}</span>
      </div>
      <div className="text-2xl mb-1 text-gray-900">{count}개사</div>
      <div className="text-xs text-gray-700 mb-2">월평균 {avgRevenue}</div>
    </div>
  );
}

// AI Insight Row Component
function AIInsightRow({ 
  text, 
  priority 
}: { 
  text: string, 
  priority: 'high' | 'medium' | 'low' 
}) {
  const priorityColor = {
    high: 'bg-red-50 text-red-600',
    medium: 'bg-yellow-50 text-yellow-600',
    low: 'bg-green-50 text-green-600'
  }[priority];

  return (
    <div className={`flex items-center gap-2 ${priorityColor} rounded-lg p-2`}>
      <Sparkles className="w-4 h-4" />
      <span className="text-sm">{text}</span>
    </div>
  );
}

// Alert Row Component
function AlertRow({ 
  icon, 
  text, 
  count, 
  bgColor 
}: { 
  icon: React.ReactNode, 
  text: string, 
  count: number, 
  bgColor: string 
}) {
  return (
    <div className={`flex items-center gap-2 ${bgColor} rounded-lg p-2`}>
      {icon}
      <span className="text-sm">{text}</span>
      <span className="text-xs px-2 py-0.5 rounded-full bg-red-500 text-white">
        {count}
      </span>
    </div>
  );
}

// Feedback Row Component
function FeedbackRow({ 
  company, 
  rating, 
  comment 
}: { 
  company: string, 
  rating: number, 
  comment: string 
}) {
  return (
    <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg p-2">
      <span className="text-sm font-medium">{company}</span>
      <span className="text-xs text-gray-600">{comment}</span>
    </div>
  );
}

// Placeholder Page Component
function PlaceholderPage({ title }: { title: string }) {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl mb-2">{title}</h1>
        <p className="text-gray-600">이 페이지는 곧 구현될 예정입니다.</p>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-500">
        <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
        <p>{title} 기능</p>
        <p className="text-sm mt-2">렌탈 중개업체 전용 ERP·CRM 통합 솔루션</p>
      </div>
    </div>
  );
}

// AccordionSection Component
function AccordionSection({ 
  icon, 
  label, 
  isOpen, 
  onToggle, 
  color,
  children 
}: { 
  icon: React.ReactNode, 
  label: string, 
  isOpen: boolean, 
  onToggle: () => void, 
  color: string,
  children: React.ReactNode
}) {
  return (
    <div>
      <div 
        className={`px-4 py-3 rounded-lg cursor-pointer transition-colors flex items-center justify-between ${
          isOpen ? 'bg-gray-50 text-gray-900' : 'text-gray-600 hover:bg-gray-50'
        }`}
        onClick={onToggle}
      >
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-sm">{label}</span>
        </div>
        {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </div>
      {isOpen && (
        <div className="ml-4 mt-1 space-y-1">
          {children}
        </div>
      )}
    </div>
  );
}

// NestedAccordionSection Component
function NestedAccordionSection({ 
  icon,
  label, 
  isOpen, 
  onToggle, 
  children 
}: { 
  icon: React.ReactNode,
  label: string, 
  isOpen: boolean, 
  onToggle: () => void, 
  children: React.ReactNode
}) {
  return (
    <div>
      <div 
        className={`pl-8 pr-4 py-2.5 rounded-lg cursor-pointer transition-colors flex items-center justify-between ${
          isOpen ? 'bg-gray-50 text-gray-900' : 'text-gray-500 hover:bg-gray-50'
        }`}
        onClick={onToggle}
      >
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-sm">{label}</span>
        </div>
        {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </div>
      {isOpen && (
        <div className="ml-4 mt-1 space-y-1">
          {children}
        </div>
      )}
    </div>
  );
}

// SubNavItem Component
function SubNavItem({ 
  icon,
  label, 
  active, 
  onClick, 
  badge 
}: { 
  icon: React.ReactNode,
  label: string, 
  active: boolean, 
  onClick: () => void, 
  badge?: number 
}) {
  return (
    <div
      className={`pl-8 pr-4 py-2.5 rounded-lg cursor-pointer transition-colors flex items-center justify-between ${
        active ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'
      }`}
      onClick={onClick}
    >
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-sm">{label}</span>
      </div>
      {badge && (
        <span className={`text-xs px-2 py-0.5 rounded-full ${
          active ? 'bg-blue-600 text-white' : 'bg-red-500 text-white'
        }`}>
          {badge}
        </span>
      )}
    </div>
  );
}

// SubNavItemNested Component (for 3rd level menus)
function SubNavItemNested({ 
  icon,
  label, 
  active, 
  onClick
}: { 
  icon: React.ReactNode,
  label: string, 
  active: boolean, 
  onClick: () => void
}) {
  return (
    <div
      className={`pl-12 pr-4 py-2.5 rounded-lg cursor-pointer transition-colors flex items-center gap-2 ${
        active ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'
      }`}
      onClick={onClick}
    >
      {icon}
      <span className="text-sm">{label}</span>
    </div>
  );
}

// NotificationItem Component
function NotificationItem({ 
  icon, 
  title, 
  description, 
  time, 
  type 
}: { 
  icon: React.ReactNode, 
  title: string, 
  description: string, 
  time: string, 
  type: 'approval' | 'rejection' | 'maintenance' | 'contract' 
}) {
  const bgColors = {
    approval: 'hover:bg-green-50',
    rejection: 'hover:bg-red-50',
    maintenance: 'hover:bg-orange-50',
    contract: 'hover:bg-blue-50'
  };

  return (
    <div className={`p-4 border-b border-gray-100 ${bgColors[type]} transition-colors cursor-pointer`}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">{icon}</div>
        <div className="flex-1 min-w-0">
          <p className="text-sm text-gray-900 mb-1">{title}</p>
          <p className="text-xs text-gray-600 mb-2">{description}</p>
          <p className="text-xs text-gray-400">{time}</p>
        </div>
      </div>
    </div>
  );
}

// TaskRow Component
function TaskRow({ 
  label, 
  count, 
  status, 
  onClick 
}: { 
  label: string, 
  count: number, 
  status: 'info' | 'success' | 'warning' | 'urgent', 
  onClick: () => void 
}) {
  const statusClasses = {
    info: 'bg-blue-50 border-blue-200 text-blue-600',
    success: 'bg-green-50 border-green-200 text-green-600',
    warning: 'bg-orange-50 border-orange-200 text-orange-600',
    urgent: 'bg-red-50 border-red-200 text-red-600',
  }[status] || 'bg-gray-50 border-gray-200 text-gray-600';

  const bgClass = statusClasses.split(' ')[0];
  const borderClass = statusClasses.split(' ')[1];
  const textClass = statusClasses.split(' ')[2];

  return (
    <div className={`${bgClass} ${borderClass} rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer`} onClick={onClick}>
      <div className="flex items-center gap-3 mb-2">
        <div className={`${textClass}`}>
          {status === 'info' ? <Package className="w-5 h-5" /> :
          status === 'success' ? <CheckCircle className="w-5 h-5" /> :
          status === 'warning' ? <AlertTriangle className="w-5 h-5" /> :
          status === 'urgent' ? <AlertTriangle className="w-5 h-5" /> :
          <Package className="w-5 h-5" />}
        </div>
        <span className="text-sm text-gray-700 flex-1">{label}</span>
        <span className={`text-lg px-3 py-1 rounded-full ${
          status === 'urgent' ? 'bg-red-500 text-white animate-pulse' : 'bg-white text-gray-700 border border-gray-300'
        }`}>
          {count}
        </span>
      </div>
    </div>
  );
}

// CRMInsightCard Component
function CRMInsightCard({ 
  title, 
  value, 
  subtext, 
  color 
}: { 
  title: string, 
  value: string, 
  subtext: string, 
  color: string 
}) {
  const colorClasses = {
    blue: 'bg-blue-50 border-blue-200 text-blue-600',
    red: 'bg-red-50 border-red-200 text-red-600',
    orange: 'bg-orange-50 border-orange-200 text-orange-600',
    green: 'bg-green-50 border-green-200 text-green-600',
    purple: 'bg-purple-50 border-purple-200 text-purple-600',
  }[color] || 'bg-gray-50 border-gray-200 text-gray-600';

  const bgClass = colorClasses.split(' ')[0];
  const borderClass = colorClasses.split(' ')[1];
  const textClass = colorClasses.split(' ')[2];

  return (
    <div className={`${bgClass} ${borderClass} rounded-lg p-4`}>
      <div className="text-xs text-gray-600 mb-1">{title}</div>
      <div className={`text-2xl mb-1 ${textClass}`}>{value}</div>
      <div className="text-xs text-gray-500">{subtext}</div>
    </div>
  );
}

// ASRiskRow Component
function ASRiskRow({ 
  assetName, 
  riskScore, 
  reason 
}: { 
  assetName: string, 
  riskScore: number, 
  reason: string 
}) {
  const bgColor = riskScore >= 75 ? 'bg-red-50 border-red-300' : 'bg-orange-50 border-orange-300';
  const textColor = riskScore >= 75 ? 'text-red-600' : 'text-orange-600';
  const badgeColor = riskScore >= 75 ? 'bg-red-500' : 'bg-orange-500';

  return (
    <div className={`${bgColor} border rounded-lg p-4 hover:shadow-md transition-shadow`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className={`w-4 h-4 ${textColor}`} />
          <span className="text-sm">{assetName}</span>
        </div>
        <span className={`text-xs px-2 py-1 rounded-full ${badgeColor} text-white`}>
          위험도 {riskScore}%
        </span>
      </div>
      <div className="text-xs text-gray-600 pl-6">{reason}</div>
    </div>
  );
}

// ActivityLogRow Component
function ActivityLogRow({ 
  time, 
  text, 
  type 
}: { 
  time: string, 
  text: string, 
  type: 'success' | 'warning' | 'info' 
}) {
  const typeStyles = {
    success: { bg: 'bg-green-50', border: 'border-green-200', icon: <CheckCircle className="w-4 h-4 text-green-600" /> },
    warning: { bg: 'bg-yellow-50', border: 'border-yellow-200', icon: <AlertTriangle className="w-4 h-4 text-yellow-600" /> },
    info: { bg: 'bg-blue-50', border: 'border-blue-200', icon: <Bell className="w-4 h-4 text-blue-600" /> },
  }[type];

  return (
    <div className={`${typeStyles.bg} ${typeStyles.border} border rounded-lg p-3`}>
      <div className="flex items-start gap-3">
        <span className="text-xs text-gray-500 min-w-[40px]">{time}</span>
        <div className="flex-shrink-0">{typeStyles.icon}</div>
        <span className="text-sm text-gray-700 flex-1">{text}</span>
      </div>
    </div>
  );
}

// CircularGaugeCard Component
function CircularGaugeCard({ 
  title, 
  subtitle, 
  value, 
  subValue, 
  percentage, 
  color, 
  gradientId 
}: { 
  title: string, 
  subtitle: string, 
  value: string, 
  subValue: string, 
  percentage: number, 
  color: string, 
  gradientId: string 
}) {
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="bg-white rounded-xl shadow-md p-4 md:p-6 border border-gray-200">
      <div className="flex items-start gap-2 mb-2 md:mb-3">
        <TrendingUp className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
        <h3 className="text-xs text-gray-500 leading-tight">{title}</h3>
      </div>
      <div className="flex items-center gap-3 md:gap-4">
        <div className="relative w-20 h-20 md:w-24 md:h-24 flex-shrink-0">
          <svg className="transform -rotate-90 w-full h-full" viewBox="0 0 96 96">
            {/* Background circle */}
            <circle
              cx="48"
              cy="48"
              r="42"
              fill="none"
              stroke="#E5E7EB"
              strokeWidth="8"
            />
            {/* Progress circle */}
            <circle
              cx="48"
              cy="48"
              r="42"
              fill="none"
              stroke={color}
              strokeWidth="8"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-xs text-gray-500">{percentage.toFixed(0)}% 달성률</div>
            </div>
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-500 mb-0.5 md:mb-1 leading-tight">{subtitle}</p>
          <p className="text-xl md:text-2xl mb-0.5 md:mb-1 leading-tight truncate">{value}</p>
          <p className="text-xs text-gray-400 leading-tight truncate">{subValue}</p>
        </div>
      </div>
    </div>
  );
}

// PriorityAlertItem Component
function PriorityAlertItem({ 
  icon, 
  title, 
  description, 
  count, 
  bgColor 
}: { 
  icon: React.ReactNode, 
  title: string, 
  description: string, 
  count: number, 
  bgColor: string 
}) {
  return (
    <div className={`flex items-center gap-2 ${bgColor} rounded-lg p-2 md:p-3`}>
      <div className="flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-xs md:text-sm truncate">{title}</span>
          <span className="text-xs px-1.5 md:px-2 py-0.5 rounded-full bg-red-500 text-white flex-shrink-0">
            {count}
          </span>
        </div>
        <span className="text-xs text-gray-500 truncate block">{description}</span>
      </div>
    </div>
  );
}

// AllNotificationItem Component
function AllNotificationItem({ 
  icon, 
  title, 
  description, 
  time, 
  type, 
  isNew 
}: { 
  icon: React.ReactNode, 
  title: string, 
  description: string, 
  time: string, 
  type: 'approval' | 'rejection' | 'maintenance' | 'contract' 
  isNew: boolean
}) {
  const bgColors = {
    approval: 'hover:bg-green-50',
    rejection: 'hover:bg-red-50',
    maintenance: 'hover:bg-orange-50',
    contract: 'hover:bg-blue-50'
  };

  return (
    <div className={`relative p-4 border border-gray-200 rounded-lg ${bgColors[type]} transition-colors cursor-pointer ${isNew ? 'bg-blue-50/30' : 'bg-white'}`}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">{icon}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <p className="text-sm text-gray-900">{title}</p>
            {isNew && (
              <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">NEW</span>
            )}
          </div>
          <p className="text-xs text-gray-600 mb-2">{description}</p>
          <p className="text-xs text-gray-400">{time}</p>
        </div>
      </div>
    </div>
  );
}